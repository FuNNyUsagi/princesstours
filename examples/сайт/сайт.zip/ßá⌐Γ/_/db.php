<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=profandubdesc',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
