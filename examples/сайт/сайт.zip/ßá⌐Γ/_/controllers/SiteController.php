<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
//use app\models\LoginForm;
use app\models\ContactForm;
use app\models\AddInDescForm;
use app\models\Users;
use app\models\Advert;
use app\models\User;
use yii\web\UploadedFile;

class SiteController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }
    
    public function actionError() 
    {
        $exception = Yii::$app->errorHandler->exception;
        //$error_code = (int) $exception['code'];
        //return $this->render('site/error'.$error_code, $exception);
        if ($exception !== null) {
            return $this->render('error', ['exception' => $exception]);
        }
    }
    

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        $newprovider = Advert::find()->joinWith('users')->where(['status'=>'1', 'isnew'=>'1'])->orderBy('id desc')->all();
        $dataProvider = Advert::find()->joinWith('users')->where(['status'=>'1', 'isnew'=>'0'])->orderBy('weight desc')->all();
        return $this->render('index',
                ['dataProvided' => $dataProvider, 'newprovider' => $newprovider]);
    }
    
    public function actionAddadvert()
    {
         if(Yii::$app->user->isGuest){
        return $this->redirect(Yii::$app->getUrlManager()->createUrl('site/login'));
        }
        
        return $this->render('AdvertAdding');
    }

    /**
     * Login action.
     *
     * @return string
     */
    public function actionLogin()
    {
if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new Users();
        if ($model->load(Yii::$app->request->post()) 
            && $model->login()) {
            return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return string
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

     public function actionAddadv()
    {
        if(Yii::$app->user->isGuest){
        return $this->redirect(Yii::$app->getUrlManager()->createUrl('site/login'));
        }
         
        $advert = new Advert();
        $mes = $advert->addAdvert($_POST['vacancy'],$_POST['descr'],$_POST['demands'],$_POST['training'],$_POST['remoteWork'],$_POST['delayWork'],$_POST['monetization'],$_POST['skype'],
                $_POST['vk'],$_POST['mail'],$_POST['delayAnswer'], $_POST['formazaj']);
        
        Yii::$app->session->setFlash('messag', $mes);
         $this->redirect(array('/site/userroom'));
    }
    
    /**
     * Displays contact page.
     *
     * @return string
     */
    public function actionContact()
    {
        if(Yii::$app->user->isGuest){
        return $this->redirect(Yii::$app->getUrlManager()->createUrl('site/login'));
        }
        
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }
    
    public function actionAddingtodesc()
    {        
        $model = new AddInDescForm();
        if ($_POST) {
        $model->imageFile = UploadedFile::getInstance($model, 'imageFile');
        if ($model->load(['name' => $_POST['AddInDescForm']['name'], 'email' => $_POST['AddInDescForm']['email'], 'verifyCode' => $_POST['AddInDescForm']['verifyCode']], '') && $model->AddInDescForm(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('addtodescFormSubmitted');

            return $this->refresh();
        }
        }
        return $this->render('addingtodesc', [
            'model' => $model,
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionUserroom()
    {
        if(Yii::$app->user->isGuest){
        return $this->redirect(Yii::$app->getUrlManager()->createUrl('site/login'));
        }
        
        if (Yii::$app->user->can('admin')) 
        {
        $dataProvider = Advert::find()->joinWith('users')->where('status <> 5')->orderBy('weight desc')->all();
        }
        else
        {
        $id=Yii::$app->user->identity->id;
        $dataProvider = Advert::findAll(['UserID' => $id,]);
        }     
                
        return $this->render('UserRoom',
                ['dataProvided' => $dataProvider,]);
    }
    public function actionSaveadv()
    {
        if(Yii::$app->user->isGuest){
        return $this->redirect(Yii::$app->getUrlManager()->createUrl('site/login'));
        }
        
        $advert = new Advert();
        $mes = $advert->SaveAdvert($_POST['advertid']);
        return $mes;
    }
    public function actionCloseadv()
    {
        if(Yii::$app->user->isGuest){
        return $this->redirect(Yii::$app->getUrlManager()->createUrl('site/login'));
        }
        
        $advert = new Advert();
        $mes = $advert->CloseAdvert($_POST['advertid']);
        return $mes;
    }
    
        public function actionAddweight()
    {    
        $mes=array();
        $advert = new Advert();
        $mes = $advert->Addweight(trim($_POST['advertid']), trim($_POST['ipuser']));
        echo json_encode($mes);
    }
    
    public function actionChangeadv()
    {
        if(Yii::$app->user->isGuest){
        return $this->redirect(Yii::$app->getUrlManager()->createUrl('site/login'));
        }
        
        if (!isset($_POST['status']))
        {
            $status = '0';
        }
        else
        {
            $status = $_POST['status'];
        }
        
        $advert = new Advert();
        $mes = $advert->ChangeAbvert($_POST['advertid'], $status, $_POST['weight']);
        Yii::$app->session->setFlash('messag', $mes);
         $this->redirect(array('/site/userroom'));
    }
    
    public function actionAdduser()
    {
        if(Yii::$app->user->isGuest){
        return $this->redirect(Yii::$app->getUrlManager()->createUrl('site/login'));
        }
        
        $user = new User();
        $mes = $user->AddingUser($_POST['name'], $_POST['pass'], $_POST['Organizat'], $_POST['email'], $_POST['logo']);
        Yii::$app->session->setFlash('messag', $mes);
         $this->redirect(array('/site/userroom'));
    }
    
    public function actionValidateadduser ()
    {
        $error = [];
        if ($_POST['name'] == '')
        {
            $error['name'] = 'Нет логина!';
        }
        
        if ($_POST['pass'] == '')
        {
            $error['pass'] = 'Нет пароля!';
        }
        
        if ($_POST['Organizat'] == '')
        {
            $error['Organizat'] = 'Нет названия организации!';
        }
        
        if ($_POST['email'] == '')
        {
            $error['email'] = 'Нет email!';
        }
        
        if ($_POST['logo'] == '')
        {
            $error['logo'] = 'Укажите лого!';
        }
        
         
         echo json_encode($error);
    }
    
    public function actionValidateaddadvert ()
    {
        $error = [];
        if ($_POST['vacancy'] == '')
        {
            $error['vacancy'] = 'Укажите вакансию!';
        }
        
        if ($_POST['descr'] == '')
        {
            $error['descr'] = 'Укажите описание!';
        }
        
        if ($_POST['demands'] == '')
        {
            $error['demands'] = 'Укажите требования!';
        }
        
        if (($_POST['skype'] == '') && ($_POST['vk'] == '') && ($_POST['mail'] == '') && ($_POST['formazaj'] == ''))
        {
            $error['svaz'] = 'Укажите хотя бы 1 метод связи!';
        }
        
        if ($_POST['delayAnswer'] == '')
        {
            $error['delayAnswer'] = 'Укажите время ответа!';
        }
        
         
         echo json_encode($error);
    }
}
