<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "users".
 *
 * @property integer $id
 * @property string $name
 * @property string $pass
 */
class Users extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface
{
    const ROLE_USER = 1;
    const ROLE_ADMIN = 10;
    
    public $user = false;
    public $rememberMe = true;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'users';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'pass'], 'required', 'message' => 'Поле обязательно для заполнения!'],
            [['name', 'pass'], 'string', 'max' => 50],
            ['pass', 'validatePassword'],
            ['rememberMe', 'boolean'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Логин',
            'pass' => 'Пароль',
            'rememberMe' => 'Запомнить меня',
        ];
    }
        public static function findIdentity($id)
    {
        return static::findOne($id);
    }
    
    public function getId()
    {
        return $this->id;
    }
    
    public static function 
    findIdentityByAccessToken($token, $type = null)
    {
      
    }
    
    public function getAuthKey()
    {
       
    }

    public function validateAuthKey($authKey)
    {
      
    }
    
    public function login()
    {
        if ($this->validate()) {
        return Yii::$app->user->login($this->getUser(), $this->rememberMe ? 3600*24*30 : 0);
        }
    }
    
    public function getUser()
    {
        if ($this->user === false) {
        $this->user = Users::findOne(['name'=>$this->name, 
                               'pass'=>$this->pass]);
        }
        
    return $this->user;
    }
    
    public function validatePassword($attribute, $params)
    {
        if (!$this->hasErrors()) {
            if(!$this->getUser())
            {
           $this->addError($attribute, 'Неверный пароль');
            } 
        }
    }
    
    public function AddingUser($name, $pass, $Organizat, $email, $logo)
    {
        $mes='';
        
        $sd = new Users();
        $sd->name=$name;
        $sd->pass=$pass;
        $sd->Organizat=$Organizat;
        $sd->img=$logo;
        $sd->email=$email;
        $sd->role=1;
        
        if (!$sd->save())
        {
            $mes='Ошибка добавления! Повторите попытку позднее или обратитесь в службу поддержки!';
        }
        else
        {
            $mes='Готово, пользователь добавлено!';
        }
           return $mes;
           
    }
}
