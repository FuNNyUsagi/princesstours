<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "advert".
 *
 * @property integer $id
 * @property string $descr
 * @property string $demands
 * @property integer $training
 * @property integer $remote work
 * @property integer $delayWork
 * @property integer $monetization
 * @property string $skype
 * @property string $vk
 * @property string $mail
 * @property string $delayAnswer
 * @property integer $status
 * @property string $vacancy
 * @property integer $weight
 */
class Posts extends \yii\db\ActiveRecord
{
    public $file;
    /**
     * @inheritdoc
     */

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['file'], 'file'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'descr' => 'Описание',
            'demands' => 'Требования',
            'training' => 'Обучение',
            'remoteWork' => 'Удаленная работа',
            'delayWork' => 'Допустима задержка в работе',
            'monetization' => 'Возможность монетизации',
            'skype' => 'Skype',
            'vk' => 'Vk',
            'mail' => 'Email',
            'delayAnswer' => 'Приблизительное время ответа',
            'vacancy' => 'Вакансия',
        ];
    }
    
    public function getUsers()
    {
        return $this->hasOne(Users::className(), ['id' => 'UserID']);
    }
    
    public function relations()
    {
        return array(
            'users' => array(self::BELONGS_TO, 'Users', 'UserID'),
    );
    }
    
    public function getOrganizat()
    {
        return $this->users->Organizat;
    }
    
    public function getImg()
    {
        return $this->users->img;
    }
    
    public function addAdvert($vacancy,$descr,$demands,$training,$remoteWork,$delayWork,$monetization,$skype,
                $vk,$mail,$delayAnswer)
    {
        $mes='';
        if (is_null($training)) {$training='0';}
        if (is_null($remoteWork)) {$remoteWork='0';}
        if (is_null($delayWork)) {$delayWork='0';}
        if (is_null($monetization)) {$monetization='0';}
        
        $sd = new Advert();
        $sd->vacancy=$vacancy;
        $sd->descr=$descr;
        $sd->demands=$demands;
        $sd->training=$training;
        $sd->remoteWork=$remoteWork;
        $sd->delayWork=$delayWork;
        $sd->monetization=$monetization;
        $sd->skype=$skype;
        $sd->vk=$vk;
        $sd->mail=$mail;
        $sd->delayAnswer=$delayAnswer;
        $sd->UserID=Yii::$app->user->identity->id;
        
        if (!$sd->save())
        {
            $mes='Ошибка добавления! Повторите ошибку позднее или обратитесь в службу поддержки!';
        }
        else
        {
            $mes='Готово, объявление добавлено!';
        }
           return $mes;
           
    }
    
        public function SaveAdvert($id)
    {
        $mes='';
        
        $sd=Advert::find()->where(['id' => $id])->one();
        
        $sd->status='1';
        
        if (!$sd->save())
        {
            $mes='Ошибка опубликования! Повторите ошибку позднее или обратитесь в службу поддержки!';
        }
        else
        {
            $mes='Готово, объявление опубликовано!';
        }
           return $mes;
           
    }
    
            public function CloseAdvert($id)
    {
        $mes='';
        
        $sd=Advert::find()->where(['id' => $id])->one();
        
        $sd->status='5';
        
        if (!$sd->save())
        {
            $mes='Ошибка снятия! Повторите ошибку позднее или обратитесь в службу поддержки!';
        }
        else
        {
            $mes='Готово, объявление снято!';
        }
           return $mes;
           
    }
    
    public function Addweight($id)
    {
        $mes=array();
        
        $sd=Advert::find()->where(['id' => $id])->one();
        
        $mes['weight']=$sd->weight+1;
        $sd->weight=$mes['weight'];
        
        if (!$sd->save())
        {
            $mes['stat']='Ошибка поддержки! Повторите ошибку позднее или обратитесь в службу поддержки!';
        }
        else
        {
            $mes['stat']='Готово!';
            Yii::$app->response->cookies->add(new \yii\web\Cookie([
            'name' => 'isVoted'.$id,
            'value' => '1',
            ]));
        }
           return $mes;
           
    }
    
    public function ChangeAbvert($id, $status, $weight)
    {
        $mes='';
        
        $sd=Advert::find()->where(['id' => $id])->one();
        
        if (($sd->status == $status) && ($sd->weight == $weight))
        {
            $mes='Готово, объявление обновлено!';
        }
        else 
        {
            $sd->status = $status;
            $sd->weight = $weight;
            if (!$sd->save())
        {
            $mes='Ошибка обновления! Повторите ошибку позднее или обратитесь в службу поддержки!';
        }
        else
        {
            $mes='Готово, объявление обновлено!';
        }
        }
           return $mes;
           
    }
}
