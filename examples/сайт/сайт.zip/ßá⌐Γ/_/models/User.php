<?php

namespace app\models;

class User extends \yii\db\ActiveRecord
{
public static function tableName()
    {
        return 'users';
    }

            public function AddingUser($name, $pass, $Organizat, $email, $logo)
    {
        $mes='';
        
        $sd = new User();
        $sd->name=$name;
        $sd->pass=$pass;
        $sd->Organizat=$Organizat;                
        $sd->role=1;
        $sd->img=$logo;
        $sd->email=$email;
        
        if (!$sd->save())
        {
            $mes='Ошибка добавления! Повторите попытку позднее или обратитесь в службу поддержки!';
        }
        else
        {
            $mes='Готово, пользователь добавлен!';
        }
           return $mes;
           
    }
}
