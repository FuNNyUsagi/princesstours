<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\swiftmailer\Message;
use yii\web\UploadedFile;

/**
 * ContactForm is the model behind the contact form.
 */
class AddInDescForm extends Model
{
    public $name;
    public $email;
    public $verifyCode;
    public $imageFile;


    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            // name, email, subject and body are required
            [['name', 'email', 'imageFile'], 'required'],
            // email has to be a valid email address
            ['email', 'email'],
            // verifyCode needs to be entered correctly
            ['verifyCode', 'captcha'],
            [['imageFile'],'image', 'maxWidth' => 320,
                'maxHeight' => 90,],
            //['imageFile', 'file', 'skipOnEmpty' => false, 'extensions' => 'png, jpg', 'wrongExtension' => 'Допускаются только файлы с расширением png, jpg!'],
        ];
    }

    /**
     * @return array customized attribute labels
     */
    public function attributeLabels()
    {
        return [
            'verifyCode' => 'Код подтверждения',
            'name' => 'Название ТО',
            'imageFile' => 'Логотип',
        ];
    }

    /**
     * Sends an email to the specified email address using the information collected by this model.
     * @param string $email the target email address
     * @return bool whether the model passes validation
     */
    
    public function generate_guid() {
        if (function_exists('com_create_guid')){
            return com_create_guid();
        }else{
            mt_srand((double)microtime()*10000);
            $charid = strtoupper(md5(uniqid(rand(), true)));
            $hyphen = chr(45);// "-"
            $uuid = chr(123)// "{"
                .substr($charid, 0, 8).$hyphen
                .substr($charid, 8, 4).$hyphen
                .substr($charid,12, 4).$hyphen
                .substr($charid,16, 4).$hyphen
                .substr($charid,20,12)
                .chr(125);// "}"
            return $uuid;
        }
    }
    
    public function AddInDescForm($email)
    {
        $name = $this->generate_guid();
        if ($this->validate()) {
            Yii::$app->mailer->compose()
                ->setTo($email)
                ->setFrom('shkedrin@mail.ru')
                ->setSubject('Заявка на добавление')
                ->setTextBody('Здравствуйте. Пожалуйста, предоставьте доступ к вашей доске объявлений!'.chr(13).chr(13).'Имя файла в папке upload '.$name. '.' . $this->imageFile->extension.chr(13).chr(13).'С уважением, '.$this->name.chr(13).'Наш адрес: '.$this->email)
                ->send();
            
            $this->imageFile->saveAs('uploads/' . $name . '.' . $this->imageFile->extension);

            return true;
        }
        return false;
    }
    
    public function upload()
    {
        if ($this->validate()) {
            
            return true;
        } else {
            return false;
        }
    }
}
