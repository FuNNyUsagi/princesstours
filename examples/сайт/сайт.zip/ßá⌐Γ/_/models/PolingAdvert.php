<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "advert".
 *
 * @property integer $id
 * @property string $descr
 * @property string $demands
 * @property integer $training
 * @property integer $remote work
 * @property integer $delayWork
 * @property integer $monetization
 * @property string $skype
 * @property string $vk
 * @property string $mail
 * @property string $delayAnswer
 * @property integer $status
 * @property string $vacancy
 * @property integer $weight
 */
class PolingAdvert extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'pollingadvert';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [

        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
        ];
    }
    
}
