<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use yii\helpers\Url;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
	<link rel="shortcut icon" href="/web/img/favicon.png" type="image/png">
</head>
<body>
<?php $this->beginBody() ?>
<div class="wrap">
    <?php
    NavBar::begin([
        /*'brandLabel' => 'Добро пожаловать на нашу ДОСКУ ОБЪЯВЛЕНИЙ!',
        'brandUrl' => Yii::$app->homeUrl,*/
        'options' => [
            'class' => 'navbar-default navbar-fixed-top navbar-style',
        ],
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-center'],
        'items' => [
            ['label' => 'Главная', 'url' => ['/site/index']],            
            ['label' => 'Группа Вконтакте', 'url' => 'https://vk.com/profandub', 'linkOptions' => ['target' => '_blank']],
            ['label' => 'ПРО ФАНДАБ', 'url' => 'http://profandub.ru/', 'linkOptions' => ['target' => '_blank']],
            ['label' => 'Фандаб.Вики', 'url' => 'http://fandub.wiki/index.php?title=%D0%97%D0%B0%D0%B3%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F_%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0', 'linkOptions' => ['target' => '_blank']],
            !(Yii::$app->user->isGuest) ? (['label' => 'Личный кабинет', 'url' => ['/site/userroom'],'options' => ['class' => 'notmob']]) : (''),
            (!(Yii::$app->user->isGuest) && (Yii::$app->user->can('user'))) ? (['label' => 'Обратная связь', 'url' => ['/site/contact'],'options' => ['class' => 'notmob']]) : (''),
            (Yii::$app->user->isGuest) ? (['label' => 'Присоединиться к доске', 'url' => ['/site/addingtodesc'],'options' => ['class' => 'notmob']]) : (''),
            Yii::$app->user->isGuest ? (
                ['label' => 'Авторизация', 'url' => ['/site/login'], 'options' => ['class' => 'nav-right'],'options' => ['class' => 'notmob']]
            ) : (
                '<li class="nav-right notmob">'
                . Html::beginForm(['/site/logout'], 'post')
                . Html::submitButton(
                    'Выйти (' . Yii::$app->user->identity->name. ')',
                    ['class' => 'btn btn-link logout']
                )
                . Html::endForm()
                . '</li>'
            )
        ],
    ]);
    NavBar::end();
    ?>
    <div id="splash" style="position: absolute; z-index: -9999999999; width: 100%; min-width: 100%; height: 774px; max-height: 100%; min-height: 80%"></div>
    <script type="text/javascript">
        $('#splash').backstretch("/web/img/main-bg.jpg");
    </script>
    <?= (Yii::$app->controller->action->id == 'index') ? ('<p id="back-top"><a href="#top"><span></span></a></p>') : ('') ?>
    
    <div class="container">
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= $content ?>
    </div>
</div>
<script type="text/javascript">
    $( document ).ready(function() {
        $('.navbar-default .navbar-nav > li:not(.active)').hover(
            function(){
                $('.navbar-default .navbar-nav > .active > a').css('background-color','#F8F8F8');
                $('.navbar-default .navbar-nav > .active > a').css('color','#777');
            },
            function(){
                $('.navbar-default .navbar-nav > .active > a').css('background-color','#e7e7e7');
                $('.navbar-default .navbar-nav > .active > a').css('color','#555');
            }
        );

    });
</script>

<footer class="footer">
    <div class="container">
        <p class="pull-left">&copy; ProFanDub <?= date('Y') ?></p>
        <?= ((!(Yii::$app->user->isGuest)) && (Yii::$app->controller->action->id != 'contact')) ? ('<p class="pull-right" id="infoobrat">Если у Вас возникли какие-либо вопросы и пожелания, то воспользуйтесь <a href="'.Url::to(['site/contact'], true).'">формой обратной связи</a>, чтобы сообщить о них администрации</p>') : ('') ?>
    </div>    
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
