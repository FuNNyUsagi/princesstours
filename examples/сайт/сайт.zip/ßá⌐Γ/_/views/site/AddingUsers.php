<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Advert */
/* @var $form ActiveForm */
$this->registerMetaTag([
  'name' => 'robots',
  'content' => 'none'
]);
?>
<div style="margin-top:20px; margin-left: 7px;">
    <button id="add-user-button" class="btn btn-primary"> Добавить пользователя</button>
<div class="UserAdding" id="UserAdding">

    <?php $form = ActiveForm::begin([
        'action' => array('site/adduser'),
        'id' => 'formaddinguser',
            ]); ?>
    <fieldset style="width: 50%;">
        <legend><strong>Добавление нового пользователя</strong></legend>
        <label style="width: 40%; font-weight: normal;">Имя</label></label><input name="name" style="width: 60%; border-width: 0.5px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <label style="width: 40%; font-weight: normal;">Пароль</label></label><input name="pass" style="width: 60%; border-width: 0.5px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <label style="width: 40%; font-weight: normal;">Организация</label></label><input name="Organizat" style="width: 60%; border-width: 0.5px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <label style="width: 40%; font-weight: normal;">Email</label></label><input name="email" style="width: 60%; border-width: 0.5px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <label style="width: 40%; font-weight: normal;">Логотип</label></label><input name="logo" style="width: 60%; border-width: 0.5px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
<div id="adding-user-error" style="display: none; padding: 5px; margin: 10px 0;" class="alert-danger"></div>
<div style="margin-top: 10px;">
 <button class="btn btn-success" id="save-adding-user" style="margin-right: 20px;" >Добавить</button>
    <button id="button-cancel-user" class="btn btn-danger" style="float: right;"> Отмена </button>   
</div>
    </fieldset>
    <?php ActiveForm::end(); ?>

</div><!-- AdvertAdding -->
</div>
<script type="text/javascript">
$('#add-user-button').click(function() {
                        $('#UserAdding').slideToggle('slow', function () {
                            var top = $('#formaddinguser').offset().top;
                            $('body,html').animate({scrollTop: top}, 600);
                        });
                        $('#add-user-button').attr('disabled',true);
                        
		});
$('#button-cancel-user').click(function() {
                        $('#UserAdding').slideToggle('slow');
                        $('#add-user-button').attr('disabled',false);
                        $('#adding-user-error').html('');
                        $('#adding-user-error').hide();
                        $(':input','#formaddinguser')
                            .not(':button, :submit, :reset, :hidden')
                            .val('')
                            .removeAttr('checked')
                            .removeAttr('selected');
                        return false;
		});
$('#save-adding-user').click(function() {
    $.ajax({
                type: 'POST',
                dataType: 'json',
                url: '<?= \Yii::$app->getUrlManager()->createUrl('site/validateadduser') ?>',
                data: $('#formaddinguser').serialize()+'&_csrf='+'<?=Yii::$app->request->getCsrfToken()?>',
                success: function(data){
                if (data.length == 0)
                {
                    $('#formaddinguser').submit();
                }
                else
                {
                    $('#adding-user-error').html('');
                    for (var i in data) {
                        $('#adding-user-error').append('<div>'+data[i]+'</div>');
                    }   
                    $('#adding-user-error').show();
                }
            }
            });
            return false;
});
    </script>