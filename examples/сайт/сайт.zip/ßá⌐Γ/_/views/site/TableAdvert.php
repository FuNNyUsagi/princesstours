<?php
$this->registerMetaTag([
  'name' => 'robots',
  'content' => 'none'
]);
?>
<div>
    <div style="height: 30px; width: 97%">
        <div id='mememe' class="alert-success" style='margin: 0 0 7px 7px; padding: 5px; border-radius: 4px; display:none;'></div>
        <?= $this->render('message') ?>  
    </div>
    <?php
            $userid=Yii::$app->user->identity->Organizat;
            ?>            
    <table class="table-advert">
        <thead style="background-color: #0066cc">
                <tr>
                    <?php foreach (array('Номер объявления', 'Вес', 'Заголовок', 'Статус', 'Действие') as $i => $field) { ?>
                        <th style=" padding: 7px; color: #fff;">
                            <?php echo $field; ?>
                        </th>
                    <?php } ?>
                </tr>
                </thead>
                <tbody style="border-style: solid; border-width: 1px; padding: 2px;">
                <?php $i=1; foreach ($dataProvided as $result) { ?>
                    <tr style="background-color: <?php echo (($i % 2) == 0)?('#fff'):('#f3f3f3')?>">
                        <td style="padding: 7px;"><?php echo $result->id ?></td>
                        <td style=" padding: 7px; width: 80px; "><?php echo $result->weight ?></td>
                        <td style=" padding: 7px; width: 180px; "><?php echo $userid.': '.$result->vacancy ?></td>
                        <td style=" padding: 7px; width: 250px; " id="s<?php echo $result->id ?>">
                           <?php switch ($result->status) {
    case 0:
        echo "Ожидает модерации";
        break;
    case 1:
        echo "Опубликовано";
        break;
    case 2:
        echo "Отказано, необходимо переоформление";
        break;
    case 3:
        echo "Отказано, нарушает законодательство";
        break;
    case 4:
        echo "Отказано по другим причинам";
        break;
    case 5:
        echo "Снято пользователем";
        break;
}
                              ?>
                        </td>
                        <td style="padding: 7px" id="b<?php echo $result->id ?>">
                            <?php switch ($result->status) {
    case 5: ?>
                            <button class='button-save-advert btn-xs btn-success' value="<?php echo $result->id ?>"> Добавить </button>
<?php
        break;
    case 1: ?>
                            <button class='button-close-advert btn-xs btn-danger' value="<?php echo $result->id ?>"> Снять </button>
                            <?php
}
                              ?>
                        
                        </td>
                    </tr>
                <?php $i++; } ?>
                </tbody>
            </table>
</div>
<script type="text/javascript">
$(document).on('click', '.button-save-advert', function(){
  ids = $(this).attr('value');
            $.ajax({
                type: 'POST',
                url: '<?= \Yii::$app->getUrlManager()->createUrl('site/saveadv') ?>',
                 data:{
                 advertid: ids, 
                 _csrf: '<?=Yii::$app->request->getCsrfToken()?>',
                },
                success: function(data){
                    $("#mememe").html('');
                    $("#mememe").html(data);
                    $("#mememe").fadeIn(400).delay(1500).fadeOut(300);
                    $("#s"+ids).html('');
                    $("#s"+ids).html('Опубликовано');
                    $("#b"+ids).html('');
                    $("#b"+ids).html('<button class="button-close-advert btn-xs btn-danger" value="'+ids+'"> Снять </button>');
                }
            });  
});

$(document).on('click', '.button-close-advert', function(){
        ids = $(this).attr('value');
            $.ajax({
                type: 'POST',
                url: '<?= \Yii::$app->getUrlManager()->createUrl('site/closeadv') ?>',
                 data:{
                 advertid: ids, 
                 _csrf: '<?=Yii::$app->request->getCsrfToken()?>',
                },
                success: function(data){
                    $("#mememe").html('');
                    $("#mememe").html(data);
                    $("#mememe").fadeIn(400).delay(1500).fadeOut(300);
                    $("#s"+ids).html('');
                    $("#s"+ids).html('Снято пользователем');
                    $("#b"+ids).html('');
                    $("#b"+ids).html('<button class="button-save-advert btn-xs btn-success" value="'+ids+'"> Добавить </button>');
                }
            });
});
$(window).load(function () {
 $('.alert-info').delay(2500).hide(400);
});
    </script>