<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Личный кабинет';
$this->registerMetaTag([
  'name' => 'robots',
  'content' => 'none'
]);
?>
<h1><?= Html::encode($this->title) ?></h1>
<div class="user-room">
<?php if (Yii::$app->user->can('user')) { echo $this->render('TableAdvert', ['dataProvided' => $dataProvided,]); } ?>
<?php if (Yii::$app->user->can('user')) { echo $this->render('AdvertAdding'); } ?>
<?php if (Yii::$app->user->can('admin')) { echo $this->render('TableAdminAdvert', ['dataProvided' => $dataProvided,]); } ?>
<?php if (Yii::$app->user->can('admin')) { echo $this->render('AddingUsers'); } ?>
</div>