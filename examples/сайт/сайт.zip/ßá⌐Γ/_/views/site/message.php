<?php if ($flash_messages = Yii::$app->session->getFlash('messag')) {
    $this->registerMetaTag([
  'name' => 'robots',
  'content' => 'none'
]);?>
<div style="padding: 3px; margin: 5px; border-radius: 4px" class="alert-info">
					<?php echo $flash_messages; ?>
				</div>
				<?php
    ?>
<?php }?>