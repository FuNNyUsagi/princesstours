<?php
use yii\widgets\ActiveForm;
$this->registerMetaTag([
  'name' => 'robots',
  'content' => 'none'
]);
?>
<div>
    <div style="height: 30px; width: 97%">
        <div id='mememe' class="alert-success" style='margin: 0 0 7px 7px; padding: 5px; border-radius: 4px; display:none;'></div>
        <?= $this->render('message') ?>  
    </div>           
    <table class="table-advert" width="75%">
                <thead style="background-color: #0066cc">
                <tr>
                    <?php foreach (array('Номер объявления', 'Вес', 'Заголовок', 'Статус', 'Действие') as $i => $field) { ?>
                        <th style=" padding: 7px; color: #fff;">
                            <?php echo $field; ?>
                        </th>
                    <?php } ?>
                </tr>
                </thead>
                <tbody  >
                <?php $i=1; foreach ($dataProvided as $result) { ?>
                    <tr style="background-color: <?php echo (($i % 2) == 0)?('#fff'):('#f3f3f3')?>">
                        <td id='<?= $result->weight ?>' class="ww3" style="padding: 7px;" ><?php echo $result->id ?></td>
                        <td style="padding: 7px;" ><?php echo $result->weight ?></td>
                        <td style="padding: 7px;" ><?php echo $result->Organizat.': '.$result->vacancy ?></td>
                        <td style="padding: 7px;"  class='ss3' id="<?php echo $result->status ?>">
                           <?php switch ($result->status) {
    case 0:
        echo "Ожидает модерации";
        break;
    case 1:
        echo "Опубликовано";
        break;
    case 2:
        echo "Отказано, необходимо переоформление";
        break;
    case 3:
        echo "Отказано, нарушает законодательство";
        break;
    case 4:
        echo "Отказано по другим причинам";
        break;
    case 5:
        echo "Снято пользователем";
        break;
}
                              ?>
                        </td>
                        <td style="padding: 7px;" >
                            <button class='button-change-advert btn-xs btn-primary' value="<?php echo $result->id ?>"> Изменить </button>                       
                        </td>
                    </tr>
                <?php $i++; } ?>
                </tbody>
            </table>
    
    <div id="editing-advert" class="AdvertAdding">
           
 <?php $form = ActiveForm::begin([
        'action' => array('site/changeadv'),
     'id' => 'change-advert-form',
            ]); ?>
    <fieldset style="width: 70%;">
        <legend><strong>Редактирование объявления</strong></legend>
        <label style="width: 50%; font-weight: normal;">Вес</label></label><input id='numbweight' type='number' name="weight" style="width: 50%; border-width: 0.5px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <label style="width: 50%; font-weight: normal;">Опубликовано</label></label><input class='chekstatus' type="radio" name="status" value="1"/><br>
        <label style="width: 50%; font-weight: normal;">Отказано, необходимо переоформление</label></label><input class='chekstatus' type="radio" name="status" value="2"/><br>
        <label style="width: 50%; font-weight: normal;">Отказано, нарушает законодательство</label><input class='chekstatus' type="radio" name="status" value="3"/><br>
        <label style="width: 50%; font-weight: normal;">Отказано по другим причинам</label><input class='chekstatus' type="radio" name="status" value="4"/><br>
        <input type="hidden" id='advertid' value="" name='advertid' />
<div id='add-advert-error' style="display: none"></div>
<div style="margin-top: 10px;">
 <button type="submit" id='button-save-change' class="btn btn-success" style="margin-right: 20px;">Сохранить</button>
    <button id='button-change-close' class="btn btn-danger" style="float: right;">Отмена</button>   
</div>
    </fieldset>
        
    <?php ActiveForm::end(); ?>
    </div>
</div>
<script type="text/javascript">        

$(document).on('click', '.button-change-advert', function(){
$(".button-change-advert").attr('disabled',true);
weig = $(this).parent().parent().find('.ww3').attr('id');
  ids = $(this).attr('value');
  sts = $(this).parent().parent().find('.ss3').attr('id');
 $('#advertid').val(ids);
 $('#numbweight').val(weig);
 if (sts != 0)
 {
 var block = $('.chekstatus');
block.each( function() {
if ($(this).val() == sts)
{
    $(this).attr('checked', true);
}
}
        );
 }
 $('#editing-advert').slideDown('slow');
 top = $('#change-advert-form').offset().top;
 $('body,html').animate({scrollTop: top}, 1500);
}); 

$(document).on('click', '#button-change-close', function(){
$(".button-change-advert").attr('disabled',false);
 $('#editing-advert').slideUp('slow');
 $('.chekstatus').attr('checked', false)
$("#change-advert-form")[0].reset();
 return false;
});

$(window).load(function () {
 $('.alert-info').delay(2500).hide(400);
});

/*$(document).on('click', '.button-save-change', function(){
if ($('#numbweight').val() == '')
    {
        $('#add-advert-error').html('Укажите нужное количество баллов!');
        $('#add-advert-error').show();
        return false;
    }
    
$('#change-advert-form').submit();
}); */
    </script>