<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model app\models\ContactForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\captcha\Captcha;

$this->title = 'Заявка на присоединение к доске';
$this->registerMetaTag([
  'name' => 'robots',
  'content' => 'none'
]);
?>
<div class="site-contact">
    <h1><?= Html::encode($this->title) ?></h1>

    <?php if (Yii::$app->session->hasFlash('addtodescFormSubmitted')): ?>

        <div class="alert alert-success">
            Спасибо за заявку. Мы ответим Вам в ближайшее время.
        </div>
    <?php else: ?>
        <p>
            Заполните все поля для сотавления заявки и пришлите её нам.
        </p>
        <div class="row">
            <div>

                <?php $form = ActiveForm::begin(['id' => 'addindesc-form', 'options' => ['class' => 'addingdesc-form']]); ?>

                    <?= $form->field($model, 'name')->textInput(['autofocus' => true]) ?>

                    <?= $form->field($model, 'email') ?>
                
                    <?= $form->field($model, 'imageFile', [
    'template' => "{label}\n<span class='btn btn-info input-wrap'>Выбрать файл...{input}</span><span class='namefileimg'>Рекомендуемый размер изображения - 320×90 и меньше!</span>\n{hint}\n{error}"
])->fileInput() ?>

                    <?= $form->field($model, 'verifyCode')->widget(Captcha::className(), [
                        'template' => '<div class="row"><div class="col-lg-3">{image}</div><div class="col-lg-6">{input}</div></div>',
                    ]) ?>                
                    
                    
                    <div class="form-group">
                        <?= Html::submitButton('Отправить', ['class' => 'btn btn-primary', 'name' => 'addindesc-button']) ?>
                    </div>

                <?php ActiveForm::end(); ?>

            </div>
        </div>

    <?php endif; ?>
</div>
<script type="text/javascript">
        $('#addindescform-imagefile').change(function() {
                        $('.namefileimg').html($(this).val());
                        return false;
		});
                
</script>
