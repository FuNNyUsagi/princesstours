<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Advert */
/* @var $form ActiveForm */
$this->registerMetaTag([
  'name' => 'robots',
  'content' => 'none'
]);

$this->registerCssFile('@web/css/inputmask.css');
$this->registerJsFile('@web/js/jquery.inputmask.bundle.min.js');
?>
<div style="margin-top:20px;">
    <button id="add-advert-button" class="btn btn-primary"> Добавить объявление</button>
<div class="AdvertAdding" id="AdvertAdding">

    <?php $form = ActiveForm::begin([
        'action' => array('site/addadv'),
        'id' => 'formaddingadvert',
            ]); ?>
    <fieldset style="width: 50%;">
        <legend><strong>Добавление объявления</strong></legend>
        <label style="width: 40%; font-weight: normal;">Вакансия</label><input name="vacancy" style="width: 60%; border-width: 0.5px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <label style="width: 40%; font-weight: normal;">Описание</label><input name="descr" style="width: 60%; border-width: 1px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <label style="width: 40%; font-weight: normal;">Требования</label><input name="demands" style="width: 60%; border-width: 1px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <hr>
        <label> Условия работы</label><br>
        <label style="width: 40%; font-weight: normal;">Обучение</label><span style="width: 55%; text-align: left;"><input type="checkbox" name="training" value="1" /></span><br>
        <label style="width: 40%; font-weight: normal;">Удаленная работа</label><span style="width: 55%; text-align: left;"><input type="checkbox" name="remoteWork" value="1" /></span><br>
        <label style="width: 40%; font-weight: normal;">Допустима задержка в работе</label><span style="width: 55%; text-align: left;"><input type="checkbox" name="delayWork" value="1" /></span><br>
        <label style="width: 40%; font-weight: normal;">Возможность монетизации</label><span style="width: 55%; text-align: left;"><input type="checkbox" name="monetization" value="1" /></span><br>
        <hr>
        <label> Метод связи</label><br>
        <label style="width: 40%; font-weight: normal;">Skype</label><input name="skype" style="width: 60%; border-width: 1px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <label style="width: 40%; font-weight: normal;">Vk</label><input name="vk" style="width: 60%; border-width: 1px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <label style="width: 40%; font-weight: normal;">Email</label><input id="mail" name="mail" style="width: 60%; border-width: 1px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <label style="width: 40%; font-weight: normal;">Ссылка на форму</label><input name="formazaj" style="width: 60%; border-width: 1px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
        <hr style="margin-bottom: 10px;">
        <label style="width: 40%; font-weight: normal;">Время ответа</label><input name="delayAnswer" style="width: 60%; border-width: 1px; border-style: solid; border-color:#555; border-radius: 5px;"/><br>
<div id='add-advert-error' style="display: none; padding: 5px; margin: 10px 0;" class="alert-danger"></div>
<div style="margin-top: 10px;">
    <button type="submit" class="btn btn-success" style="margin-right: 20px;" id="save-adding-advert">Добавить</button>
    <button id="button-cancel-advert" class="btn btn-danger" style="float: right;"> Отмена </button>
</div>
    </fieldset>

    
    
    <?php ActiveForm::end(); ?>

</div><!-- AdvertAdding -->
</div>
<script type="text/javascript">
$('#add-advert-button').click(function() {
    $('#AdvertAdding').slideToggle('slow', function () {
        var top = $('#formaddingadvert').offset().top;
        $('body,html').animate({scrollTop: top}, 600);
    });
    $('#add-advert-button').attr('disabled',true);
    
});
$('#button-cancel-advert').click(function() {
    $('#AdvertAdding').slideToggle('slow');
    $('#add-advert-button').attr('disabled',false);
    $('#add-advert-error').html('');
    $('#adding-user-error').hide();
    $(':input','#formaddingadvert')
        .not(':button, :submit, :reset, :hidden')
        .val('')
        .removeAttr('checked')
        .removeAttr('selected');
    return false;
});
$('#save-adding-advert').click(function() {
    $.ajax({
        type: 'POST',
        dataType: 'json',
        url: '<?= \Yii::$app->getUrlManager()->createUrl('site/validateaddadvert') ?>',
        data: $('#formaddingadvert').serialize()+'&_csrf='+'<?=Yii::$app->request->getCsrfToken()?>',
        success: function(data){
            if (data.length == 0)
            {
                $('#formaddingadvert').submit();
            }
            else
            {
                $('#add-advert-error').html('');
                for (var i in data) {
                    $('#add-advert-error').append('<div>'+data[i]+'</div>');
                }   
                $('#add-advert-error').show();
            }
        }
    });
    return false;
});
$(document).ready(function(){
  $('#mail').inputmask({alias:"email", clearIncomplete:true});
});
</script>