<?php

/* @var $this yii\web\View */
use yii\helpers\Html;
use app\models\PolingAdvert;
$this->title = 'ДОСКА';
$this->registerMetaTag([
  'name' => 'description',
  'content' => 'Доска объявлений с вакансиями дабберов, таймеров, переводчиков, звукорежиссеров'
]);
$this->registerMetaTag([
  'name' => 'keywords',
  'content' => 'доска объявления вакансия даббер таймер переводчик звукорежиссер профандаб profandub'
]);
$this->registerCssFile('@web/css/simple-hint.min.css');
?>
<div>   
    
    <div style="text-align: center; margin-bottom: 100px; margin-top: 400px;">
    <h2>Стать даббером, таймером, переводчиком, звукорежиссером</h2>
    <h4>Доска объявлений</h4>
    </div>
    <?php if ($newprovider) { ?>
    <div class="block-new-adverts">
    <div class="label-new-adv-top">Новинка!</div>
<?php foreach ($newprovider as $news) {?>
    <div id='<?= $news->id ?>' class="block-advert">        
        <div class="block-advert-cont">
            <div class="svaz">
                <h4 class="lbl-center"><span class="hint-top-left-mobile hint-fade" data-hint="Нажмите, чтобы увидеть полные адреса и названия"><?php echo Html::img('@web/img/show-all.png', $options = ['class' => 'show-all',]) ?></span>Методы связи:</h4>
                <hr>
                <div style="padding:0 5px;">                    
            <?php if ($news->skype)
            { ?>
                    <a href="skype:<?php echo $news->skype ?>" title="Связаться по Skype"><?php echo Html::img('@web/img/skype.png', $options = ['class' => 'icon-svaz',]) ?></a><input class="poln-adres" readonly="true" value="<?php echo $news->skype ?>" style="display:none; margin-left: 10px; border: none; border-radius: 4px; background-color: #e5e5e5; font-weight: 600; width: 80%">
            <?php }
            if ($news->vk)
            { ?>
               <a href="<?php echo $news->vk ?>" target="_blank" title="Написать в ВК"><?php echo Html::img('@web/img/vk.png', $options = ['class' => 'icon-svaz',]) ?></a><input class="poln-adres" readonly="true" value="<?php echo $news->vk ?>" style="display:none; margin-left: 10px; border: none; border-radius: 4px; background-color: #e5e5e5; font-weight: 600; width: 80%">
            <?php }
            if ($news->mail)
            { ?>
               <a href="mailto:<?php echo $news->mail ?>" title="Связаться по почте"><?php echo Html::img('@web/img/mail.png', $options = ['class' => 'icon-svaz',]) ?></a><input class="poln-adres" readonly="true" value="<?php echo $news->mail ?>" style="display:none; margin-left: 10px; border: none; border-radius: 4px; background-color: #e5e5e5; font-weight: 600; width: 80%">
            <?php } 
            if ($news->FormaZajav)
            { ?>
               <a href="<?php echo $news->FormaZajav ?>" target="_blank" title="Перейти к форме заявки на сайте"><?php echo Html::img('@web/img/form.png', $options = ['class' => 'icon-svaz',]) ?></a><input class="poln-adres" readonly="true" value="<?php echo $news->FormaZajav ?>" style="display:none; margin-left: 10px; border: none; border-radius: 4px; background-color: #e5e5e5; font-weight:600; width: 80%">
            <?php } ?>
                </div>
                <hr>
                <b>Приблизительное время ответа:</b> <br><p style="word-break: break-all;"><?php echo $news->delayAnswer ?></p>
                <hr style="margin: 20px 0">
            </div>
        <h4 class="lbl-center"><?= $news->Organizat?>: <?php echo $news->vacancy ?></h4>
        <hr style="margin: 20px 0">
        <div id="img-cont"><?php echo Html::img('@web/uploads/'.$news->img, $options = ['class' => 'img-devsc',]) ?>
            <!--<div class="img-devsc-otr" style="background-image: -moz-linear-gradient(top, #fff 65%, transparent 100%), url('</?=Yii::getAlias('@web/uploads/'.$news->img)?>')"></div>-->
        </div>
        <b>Описание:</b><br> <p class="lbl-left"><?php echo $news->descr ?></p><hr>
        <b>Требования:</b><br> <p class="lbl-left"><?php echo $news->demands ?></p><hr>
        <label><b>Условия работы или их отсутствие:</b></label><br>
        <input type="checkbox" disabled <?= $news->training ? ('checked'):('') ?> name="training" style="margin-right: 10px; "/><label style='color: <?= $news->training ? ('#9e9'):('#faa') ?>;'>Обучение</label><br>
        <input type="checkbox" disabled <?= $news->remoteWork ? ('checked'):('') ?> name="remoteWork" style="margin-right: 10px"/><label style='color: <?= $news->remoteWork ? ('#9e9'):('#faa') ?>;'>Удаленная работа</label><br>
        <input type="checkbox" disabled <?= $news->delayWork ? ('checked'):('') ?> name="delayWork" style="margin-right: 10px"/><label style='color: <?= $news->delayWork ? ('#9e9'):('#faa') ?>;'>Допустима задержка в работе</label><br>
        <input type="checkbox" disabled <?= $news->monetization ? ('checked'):('') ?> name="monetization" style="margin-right: 10px"/><label style='color: <?= $news->monetization ? ('#9e9'):('#faa') ?>;'>Возможность монетизации</label><br>
        <br>
        <div style="display: inline-block; float: left;">
        <Div class="showsvaz">            
            <span class="show-cont btn-sm btn-warning">На связь!</span>
        </div>
        </div>
        
        <?php if (!PolingAdvert::find()->where(['ipadress' => Yii::$app->request->userIP, 'advertid' => $news->id])->one()) 
        { ?>
        <div class="add-weigh-container">
        <Div class="add-weight" id='<?= $news->id ?>'>            
            <span class="like-adv btn-sm btn-info"> Поддержать</span>  
            <label class="err" style="display: none"></label>
        </div>
        </div>
        <?php } else {?>
            <div class="add-weigh-container">
         <span class="success-like"> Вы проголосовали!</span>
            </div>
        <?php } ?>
        </div> <br>
        <label class="weightnome">Баллов: <?php echo $news->weight ?></label><br>
        <hr style="margin-top: 5px;">
    </div>
<?php } ?>
    <div class="label-new-adv-bottom">Новинка!</div>
</div>
    <?php } ?>
    <div class="block-main-advert">
<?php foreach ($dataProvided as $result) { ?>
    <div id='<?= $result->id ?>' class="block-advert">
        <div class="block-advert-cont main-cont-adv">
            <div class="svaz">
                <h4 class="lbl-center"><span class="hint-top-left-mobile hint-fade" data-hint="Нажмите, чтобы увидеть полные адреса и названия"><?php echo Html::img('@web/img/show-all.png', $options = ['class' => 'show-all',]) ?></span>Методы связи:</h4>
                <hr>
                <div style="padding:0 5px;">                    
            <?php if ($result->skype)
            { ?>
                    <a href="skype:<?php echo $result->skype ?>" title="Связаться по Skype"><?php echo Html::img('@web/img/skype.png', $options = ['class' => 'icon-svaz',]) ?></a><input class="poln-adres" readonly="true" value="<?php echo $result->skype ?>">
            <?php }
            if ($result->vk)
            { ?>
               <a href="<?php echo $result->vk ?>" target="_blank" title="Написать в ВК"><?php echo Html::img('@web/img/vk.png', $options = ['class' => 'icon-svaz',]) ?></a><input class="poln-adres" readonly="true" value="<?php echo $result->vk ?>">
            <?php }
            if ($result->mail)
            { ?>
               <a href="mailto:<?php echo $result->mail ?>" title="Связаться по почте"><?php echo Html::img('@web/img/mail.png', $options = ['class' => 'icon-svaz',]) ?></a><input class="poln-adres" readonly="true" value="<?php echo $result->mail ?>">
            <?php } 
            if ($result->FormaZajav)
            { ?>
               <a href="<?php echo $result->FormaZajav ?>" target="_blank" title="Перейти к форме заявки на сайте"><?php echo Html::img('@web/img/form.png', $options = ['class' => 'icon-svaz',]) ?></a><input class="poln-adres" readonly="true" value="<?php echo $result->FormaZajav ?>">
            <?php } ?>
                </div>
                <hr>
                <b style="margin-left: 2px;">Приблизительное время ответа:</b> <br><p style="word-break: break-all; margin-left: 2px;"><?php echo $result->delayAnswer ?></p>
                <hr style="margin: 20px 0">
            </div>
        <h4 class="lbl-center" ><?= $result->Organizat?>: <?php echo $result->vacancy ?></h4>
        <hr style="margin: 20px 0">
        <div id="img-cont"><?php echo Html::img('@web/uploads/'.$result->img, $options = ['class' => 'img-devsc',]) ?>
            <!--<div class="img-devsc-otr" style="background-image: -moz-linear-gradient(top, #fff 65%, transparent 100%), url('</?=Yii::getAlias('@web/uploads/'.$result->img)?>')"></div>-->
        </div>
        <b>Описание:</b><br> <p class="lbl-left"><?php echo $result->descr ?></p><hr>
        <b>Требования:</b><br> <p class="lbl-left"><?php echo $result->demands ?></p><hr>
        <label><b>Условия работы или их отсутствие:</b></label><br>
        <input type="checkbox" disabled <?= $result->training ? ('checked'):('') ?> name="training" style="margin-right: 10px; "/><label style='color: <?= $result->training ? ('#9e9'):('#faa') ?>;'>Обучение</label><br>
        <input type="checkbox" disabled <?= $result->remoteWork ? ('checked'):('') ?> name="remoteWork" style="margin-right: 10px"/><label style='color: <?= $result->remoteWork ? ('#9e9'):('#faa') ?>;'>Удаленная работа</label><br>
        <input type="checkbox" disabled <?= $result->delayWork ? ('checked'):('') ?> name="delayWork" style="margin-right: 10px"/><label style='color: <?= $result->delayWork ? ('#9e9'):('#faa') ?>;'>Допустима задержка в работе</label><br>
        <input type="checkbox" disabled <?= $result->monetization ? ('checked'):('') ?> name="monetization" style="margin-right: 10px"/><label style='color: <?= $result->monetization ? ('#9e9'):('#faa') ?>;'>Возможность монетизации</label><br>
        <br>
        <div style="display: inline-block; float: left;">
        <Div class="showsvaz">            
            <span class="show-cont btn-sm btn-warning">На связь!</span>
        </div>
        </div>
        
        <?php if (!PolingAdvert::find()->where(['ipadress' => Yii::$app->request->userIP, 'advertid' => $result->id])->one()) 
        { ?>
        <div class="add-weigh-container">
        <Div class="add-weight" id='<?= $result->id ?>'>            
            <span class="like-adv btn-sm btn-info"> Поддержать</span>  
            <label class="err" style="display: none"></label>
        </div>
        </div>
        <?php } else {?>
            <div class="add-weigh-container">
         <span class="success-like"> Вы проголосовали!</span>
            </div>
        <?php } ?>
        </div> <br>
        <label class="weightnome">Баллов: <?php echo $result->weight ?></label><br>
        <hr style="margin-top: 5px;">
    </div>
    <?php } ?>
    </div>
</div>

<script type="text/javascript">
$(document).on('click', '.btn-spoiler', function(){
$(this).parent().parent().find(".spoilers").slideToggle('slow');
var test = $(this).parent();
if ($(this).parent().css("background-color") == "rgb(221, 221, 221)")
{
    setTimeout(function(){$.proxy(test.css("background-color", "#ffffff"), test);}, 600);
}
else
{
    $(this).parent().css("background-color", "#dddddd");
}
});
        
$(document).on('click', '.add-weight', function(){
    ids = $(this).attr('id');
                $.ajax({
                type: 'POST',
                dataType: 'json',
                url: '<?= \Yii::$app->getUrlManager()->createUrl('site/addweight') ?>',
                 data:{
                 advertid: ids,
                 ipuser: '<?=Yii::$app->request->userIP?>',
                 _csrf: '<?=Yii::$app->request->getCsrfToken()?>',
                },
                success: $.proxy(function(data){
                    $(this).parent().hide();
                    $(this).hide();
                    $(this).parent().parent().parent().children('.weightnome').html('Баллов: '+data['weight']);
                    $(this).parent().append('<span class="success-like"> Вы проголосовали!</span>');
                    $(this).parent().fadeIn(600);
                    
                    /*$(this).parent().find(".err").html('');
                    $(this).parent().find(".err").html(data['stat']);
                   $(this).parent().find(".err").fadeIn(400).delay(600).fadeOut(300);
                    
                    $(this).parent().find(".weightnome").html('');
                    $(this).parent().find(".weightnome").html('Вес: '+data['weight']);*/
                }, $(this))
            });
            
});

$(document).on('click', '.showsvaz', function(){
    if ($(this).parent().parent().children('.svaz').is(":visible"))
    {
        $(this).parent().parent().children('.svaz').children('div').children('.poln-adres').hide('slow')
        $(this).html('<span class="show-cont btn-sm btn-warning">На связь!</span>');
        $(this).parent().parent().children('.svaz').slideUp();
    }
    else
    {
        $(this).html('<span class="show-cont btn-sm btn-danger">Закрыть</span>');
        $(this).parent().parent().children('.svaz').slideDown();
    }
    
}); 

$(document).on('click', '.show-all', function(){
    if (!($(this).parent().parent().parent().children('div').children('.poln-adres').is(":visible")))
    {
        $(this).parent().parent().parent().children('div').children('.poln-adres').show('slow');    
    }
    else
    {
        $(this).parent().parent().parent().children('div').children('.poln-adres').hide('slow');
    }
    
    
});

$(document).ready(function(){

    // hide #back-top first
    $("#back-top").hide();
    if ($(window).width() > 400)
    {
    // fade in #back-top
    $(function () {
        $(window).scroll(function () {
            if ($(this).scrollTop() > 100) {
                $('#back-top').fadeIn();
            } else {
                $('#back-top').fadeOut();
            }
        });

        // scroll body to 0px on click
        $('#back-top a').click(function () {
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
    });
}
});
</script>
