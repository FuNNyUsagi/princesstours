<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model app\models\ContactForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\captcha\Captcha;

$this->title = 'Обращение к администрации';
$this->registerMetaTag([
  'name' => 'robots',
  'content' => 'none'
]);
?>
<div class="site-contact">
    <h1><?= Html::encode($this->title) ?></h1>

    <?php if (Yii::$app->session->hasFlash('contactFormSubmitted')): ?>

        <div class="alert alert-success">
            Спасибо, что связались с нами. Мы ответим Вам так скоро, насколько это возможно.
        </div>
    <?php else: ?>

        <p style='background: #fff; padding: 10px; border-style: solid; border-width: 1px; border-color: #999; border-radius: 5px; width: 70%;'>
            Если у Вас имеются какие-либо вопросы и пожелания, заполните следующую форму, чтобы связаться с нами.
        </p>

        <div>
            <div>

                <?php $form = ActiveForm::begin(['id' => 'contact-form', 'options' => ['class' => 'email-form']]); ?>

                    <?= $form->field($model, 'subject') ?>

                    <?= $form->field($model, 'body')->textarea(['rows' => 6]) ?>


                    <div class="form-group">
                        <?= Html::submitButton('Отправить', ['class' => 'btn btn-primary', 'name' => 'contact-button']) ?>
                    </div>

                <?php ActiveForm::end(); ?>

            </div>
        </div>

    <?php endif; ?>
</div>
