<?php

/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

use yii\helpers\Html;

$this->title = $name;
$this->registerMetaTag([
  'name' => 'robots',
  'content' => 'none'
]);
?>
<div class="site-error">

    <h1><?= Html::encode($this->title) ?></h1>

    <div class="alert alert-danger">
        <?= nl2br(Html::encode($message)) ?>
    </div>

    <p style='background: #fff; padding: 10px; border-style: solid; border-width: 1px; border-color: #999; border-radius: 5px;'>
        Раз Вы здесь, то что-то пошло не так))) Пожалуйста, воспользуйтесь формой обратной связи и сообщите об ошибке.
    </p>

</div>
