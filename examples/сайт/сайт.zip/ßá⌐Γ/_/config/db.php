<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=u0004106_infandub',
    'username' => 'u0004106_ifdsite',
    'password' => 'YTjiyDdn',
    'charset' => 'utf8',
];
