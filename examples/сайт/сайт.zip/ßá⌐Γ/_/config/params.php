<?php

return [
    'adminEmail' => 'mozilla-93@mail.ru',
];
